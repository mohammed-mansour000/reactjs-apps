import React from 'react'
import { useParams } from 'react-router-dom';

function ExerciseDetail() {
	const {id} = useParams();
	console.log("id",id)
  return (
    <div>ExerciseDetail</div>
  )
}

export default ExerciseDetail